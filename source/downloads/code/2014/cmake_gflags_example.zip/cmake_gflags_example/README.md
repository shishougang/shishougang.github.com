README
======
A simple example of using gflag for this (article)[http://dreamrunner.org/blog/2014/03/09/gflags-jian-ming-shi-yong].


Dependencies
============

  * C++ compiler and Make
    - Mac OSX https://developer.apple.com/xcode/
    - Linux   http://gcc.gnu.org/
  * CMake
    - http://www.cmake.org/cmake/resources/software.html

BUILDING
========

        mkdir build
        cd build && cmake ..
                

INSTALLING
==========

 Once the project has been built (see "BUILDING"), execute
 
 sudo make install


